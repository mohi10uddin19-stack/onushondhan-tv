const firebaseConfig = {
  apiKey: "AIzaSyAPP-Z3985x6e6Is2noMxQZ0JAWVILAceU",
  authDomain: "onushondhan-v.firebaseapp.com",
  projectId: "onushondhan-v",
  storageBucket: "onushondhan-v.firebasestorage.app",
  messagingSenderId: "669433176030",
  appId: "1:669433176030:web:bc736dad4c3926b287074f"
};

if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

function msg(text, ok=false) {
  const el = document.getElementById("loginMsg") || document.getElementById("pubMsg");
  if (el) { el.textContent = text; el.style.color = ok ? "green" : "crimson"; }
}

async function login() {
  const email = document.getElementById("user")?.value.trim();
  const password = document.getElementById("pass")?.value;
  if (!email || !password) return msg("Email ও Password দিন।");
  try {
    await auth.signInWithEmailAndPassword(email, password);
    msg("Login সফল হয়েছে।", true);
    loadAdminNews();
  } catch (e) { console.error(e); msg("Login হয়নি: " + e.message); }
}

async function logout() { await auth.signOut(); }

async function publish() {
  if (!auth.currentUser) return msg("আগে Admin Login করুন।");
  const title = document.getElementById("title")?.value.trim();
  const category = document.getElementById("category")?.value.trim();
  const image = document.getElementById("image")?.value.trim();
  const body = document.getElementById("body")?.value.trim();
  if (!title || !body) return msg("শিরোনাম ও নিউজের লেখা দিন।");
  try {
    await db.collection("news").add({title, category: category || "সাধারণ", image: image || "", body, createdAt: firebase.firestore.FieldValue.serverTimestamp(), author: auth.currentUser.email});
    msg("নিউজ সফলভাবে প্রকাশ হয়েছে।", true);
    ["title","category","image","body"].forEach(id => { const el=document.getElementById(id); if(el) el.value=""; });
    loadAdminNews();
  } catch (e) { console.error(e); msg("নিউজ প্রকাশ হয়নি: " + e.message); }
}

async function loadAdminNews() {
  const list = document.getElementById("adminList");
  if (!list) return;
  try {
    const snap = await db.collection("news").orderBy("createdAt","desc").limit(20).get();
    list.innerHTML="";
    snap.forEach(doc => { const div=document.createElement("div"); div.className="panel"; div.textContent=doc.data().title||""; list.appendChild(div); });
  } catch(e) { console.error(e); list.textContent="নিউজ তালিকা লোড হয়নি: "+e.message; }
}

auth.onAuthStateChanged(user => {
  const loginBox=document.getElementById("loginBox"), dash=document.getElementById("dash");
  if(loginBox && dash){ loginBox.style.display=user?"none":"block"; dash.style.display=user?"block":"none"; }
});
